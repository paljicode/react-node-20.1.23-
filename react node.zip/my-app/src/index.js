import ReactDOM from 'react-dom/client'
import App from './component/App';
// console.log(ReactDOM);



const root=ReactDOM.createRoot(document.getElementById('root'));

// console.log(root);
// root.render(<h1>Hello..</h1>)
root.render(<App/>)