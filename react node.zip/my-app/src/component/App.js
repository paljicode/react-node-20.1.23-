import React from 'react'
import Containt from './Containt'
import Footer from './Footer'
import Header from './Header'

export default function App() {
  return (
    <div>
      <Header/>
      <Containt/>
      <Footer/>
    </div>
  )
}
